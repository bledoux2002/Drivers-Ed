INSTRUCTIONS
Movement - WASD (keyboard), Left joystick (controller)
Boost - Left shift (keyboard), South button (A on Xbox, Cross on Playstation)
Brake - Space bar (keyboard), East button (B on Xbox, Circle on Playstation)

You can drift slightly off-road, but there is a limit that will cause a game-over screen.
As long as you pass a car facing the same direction as you it will add to your score (dropping behind a car decrements it).
Returning to the menu will save the game automatically, the same as the save button would.